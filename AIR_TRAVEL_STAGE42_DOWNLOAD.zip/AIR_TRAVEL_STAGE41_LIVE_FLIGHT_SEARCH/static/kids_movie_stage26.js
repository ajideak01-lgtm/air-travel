(()=>{
'use strict';
const picker=document.getElementById('kidsMovieFiles');
const player=document.getElementById('kidsPlayer');
if(!picker||!player)return;
const list=document.getElementById('kidsMoviePlaylist');
const title=document.getElementById('kidsMovieTitle');
const status=document.getElementById('kidsMovieStatus');
const count=document.getElementById('kidsMovieQueueCount');
const previous=document.getElementById('kidsPreviousMovie');
const next=document.getElementById('kidsNextMovie');
const clear=document.getElementById('kidsClearMovies');
const MAX_ITEMS=20;
const allowedTypes=new Set(['video/mp4','video/webm','video/ogg']);
const allowedExtensions=/\.(mp4|webm|ogv|ogg)$/i;
const queue=[];
let current=-1;
let currentUrl=null;
let objectUrls=new Set();
let changing=false;
const bytes=n=>{if(!Number.isFinite(n)||n<=0)return '';const units=['B','KB','MB','GB'];let v=n,i=0;while(v>=1024&&i<units.length-1){v/=1024;i++;}return `${v.toFixed(i?1:0)} ${units[i]}`;};
const safeName=f=>String(f.name||'Video').replace(/[<>]/g,'').slice(0,120);
function releaseCurrent(){
  player.pause();
  player.removeAttribute('src');
  player.load();
  if(currentUrl){URL.revokeObjectURL(currentUrl);objectUrls.delete(currentUrl);currentUrl=null;}
}
function setStatus(message){status.textContent=message;}
function updateControls(){
  count.textContent=`${queue.length} ${queue.length===1?'video':'videos'}`;
  previous.disabled=queue.length===0||current<=0;
  next.disabled=queue.length===0||current>=queue.length-1;
  clear.disabled=queue.length===0;
}
function renderQueue(){
  list.replaceChildren();
  if(!queue.length){const empty=document.createElement('li');empty.className='kids-empty-playlist';empty.textContent='Your selected videos will appear here.';list.append(empty);}
  queue.forEach((item,index)=>{
    const row=document.createElement('li');row.className='kids-playlist-row'+(index===current?' is-current':'');
    const select=document.createElement('button');select.type='button';select.className='kids-playlist-select';select.textContent=`${index===current?'▶ ':' '} ${index+1}. ${item.name}`;select.setAttribute('aria-current',index===current?'true':'false');select.addEventListener('click',()=>playAt(index));
    const size=document.createElement('small');size.textContent=bytes(item.file.size);
    const remove=document.createElement('button');remove.type='button';remove.className='kids-playlist-remove';remove.textContent='Remove';remove.setAttribute('aria-label',`Remove ${item.name}`);remove.addEventListener('click',()=>removeAt(index));
    row.append(select,size,remove);list.append(row);
  });
  updateControls();
}
function isSupported(file){
  const type=(file.type||'').toLowerCase();
  return allowedTypes.has(type)||(!type&&allowedExtensions.test(file.name||''));
}
function playAt(index){
  if(index<0||index>=queue.length)return;
  releaseCurrent();
  current=index;
  const item=queue[current];
  currentUrl=URL.createObjectURL(item.file);
  objectUrls.add(currentUrl);
  player.src=currentUrl;
  player.load();
  title.textContent=`Now showing: ${item.name}`;
  setStatus('Loading your video… Press Play if it does not start automatically.');
  renderQueue();
  // Playback is user-initiated from a button or file selection; still handle browser autoplay restrictions.
  const attempt=player.play();
  if(attempt&&typeof attempt.catch==='function')attempt.catch(()=>setStatus('Your video is ready. Press Play on the player to begin.'));
}
function addFiles(files){
  let added=0,skipped=0;
  for(const file of files){
    if(queue.length>=MAX_ITEMS){skipped++;continue;}
    if(!isSupported(file)){skipped++;continue;}
    const duplicate=queue.some(item=>item.file.name===file.name&&item.file.size===file.size&&item.file.lastModified===file.lastModified);
    if(duplicate){skipped++;continue;}
    queue.push({file,name:safeName(file)});added++;
  }
  picker.value='';
  if(added){
    const shouldStart=current<0;
    renderQueue();
    setStatus(`${added} video${added===1?'':'s'} added to your playlist.${skipped?` ${skipped} file(s) were skipped.`:''}`);
    if(shouldStart)playAt(0);
  }else{
    renderQueue();
    setStatus('No new supported videos were added. Choose MP4, WebM or OGG files. The playlist can hold up to 20 videos.');
  }
}
function removeAt(index){
  if(index<0||index>=queue.length)return;
  const wasCurrent=index===current;
  queue.splice(index,1);
  if(!queue.length){releaseCurrent();current=-1;title.textContent='Your screen is ready!';setStatus('Playlist cleared. Choose videos to start again.');}
  else if(wasCurrent){current=-1;playAt(Math.min(index,queue.length-1));}
  else if(index<current){current--;}
  renderQueue();
}
picker.addEventListener('change',()=>addFiles(Array.from(picker.files||[])));
previous.addEventListener('click',()=>playAt(current-1));
next.addEventListener('click',()=>playAt(current+1));
clear.addEventListener('click',()=>{
  releaseCurrent();queue.length=0;current=-1;title.textContent='Your screen is ready!';setStatus('Your playlist has been cleared. Your original video files are unchanged.');renderQueue();
});
player.addEventListener('ended',()=>{if(current>=0&&current<queue.length-1)playAt(current+1);else setStatus('Movie night complete! You reached the end of your playlist. 🌟');});
player.addEventListener('loadedmetadata',()=>{
  const duration=Number.isFinite(player.duration)?` · ${Math.round(player.duration/60)} min`:'';
  setStatus(`Video ready${duration}. Enjoy your movie night!`);
});
player.addEventListener('error',()=>{
  if(current>=0&&queue[current])setStatus(`This device could not play “${queue[current].name}”. Try an MP4 (H.264/AAC) or another supported video.`);
});
window.addEventListener('pagehide',()=>{
  releaseCurrent();
  for(const url of objectUrls)URL.revokeObjectURL(url);
  objectUrls.clear();
});
renderQueue();
})();
