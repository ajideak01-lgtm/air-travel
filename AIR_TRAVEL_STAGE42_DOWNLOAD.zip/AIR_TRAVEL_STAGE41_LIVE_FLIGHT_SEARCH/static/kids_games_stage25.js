(()=>{
'use strict';
const root=document.getElementById('kidsGameSave');
if(!root)return;
const endpoint=root.dataset.endpoint,csrf=root.dataset.csrf;
const status=document.getElementById('kidsGameStatus');
const $=id=>document.getElementById(id);
async function saveScore(gameKey,score,bestId){
  try{
    const response=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify({game_key:gameKey,score})});
    const data=await response.json();
    if(!response.ok||!data.ok)throw new Error(data.error||'Could not save this score.');
    $(bestId).textContent=data.best_score+'/100';
    status.textContent='Your result was saved privately to your account. No EXP was used.';
  }catch(err){status.textContent='The game was completed, but the score could not be saved. Check your connection and try another round.';}
}

// Airplane Memory Match — four pairs, keyboard-accessible buttons.
(()=>{
 const board=$('memoryBoard'),moves=$('memoryMoves'),pairs=$('memoryPairs'),message=$('memoryMessage');
 if(!board)return;
 const icons=['✈️','🌍','🎒','🛫'];let deck=[],first=null,lock=false,matched=0,turns=0,finished=false;
 function shuffle(items){for(let i=items.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[items[i],items[j]]=[items[j],items[i]];}return items;}
 function render(){board.innerHTML='';deck.forEach((card,index)=>{const b=document.createElement('button');b.type='button';b.className='kids-memory-card';b.textContent=card.open||card.done?card.icon:'?';b.setAttribute('aria-label',card.done?'Matched card':card.open?'Revealed '+card.icon:'Hidden memory card');if(card.open)b.classList.add('is-open');if(card.done){b.classList.add('is-matched');b.disabled=true;}b.addEventListener('click',()=>flip(index));board.appendChild(b);});moves.textContent=turns;pairs.textContent=matched+'/4';}
 function start(){deck=shuffle([...icons,...icons].map((icon,id)=>({id,icon,open:false,done:false})));first=null;lock=false;matched=0;turns=0;finished=false;message.textContent='Find the matching pairs!';render();}
 function flip(i){const card=deck[i];if(lock||finished||card.done||card.open)return;card.open=true;render();if(first===null){first=i;return;}turns++;if(deck[first].icon===card.icon){deck[first].done=true;card.done=true;matched++;first=null;render();if(matched===4){finished=true;const score=Math.max(0,100-(turns-4)*5);message.textContent='🎉 All four pairs found! Your score: '+score+'/100.';message.classList.add('kids-game-complete');saveScore('memory_match',score,'memoryBest');}else message.textContent='Nice match! Find another pair.';}else{lock=true;const prior=first;first=null;message.textContent='Not a match. Have another try!';window.setTimeout(()=>{deck[prior].open=false;card.open=false;lock=false;render();},850);}}
 $('memoryNew').addEventListener('click',start);start();
})();

// Airport Pattern Puzzle — short, age-friendly pattern completion.
(()=>{
 const prompt=$('sequencePrompt'),options=$('sequenceOptions'),number=$('sequenceNumber'),message=$('sequenceMessage');
 if(!prompt)return;
 const puzzles=[
  {q:'2, 4, 6, ?',a:['7','8','9','10'],correct:1},
  {q:'✈️, 🌍, ✈️, 🌍, ?',a:['🎒','✈️','⭐','🌙'],correct:1},
  {q:'Monday, Tuesday, Wednesday, ?',a:['Friday','Sunday','Thursday','Saturday'],correct:2},
  {q:'5, 10, 15, ?',a:['18','20','25','30'],correct:1},
  {q:'Red, blue, red, blue, ?',a:['Green','Blue','Yellow','Red'],correct:3}
 ];let order=[],index=0,correct=0,active=false;
 function start(){order=[...puzzles].sort(()=>Math.random()-.5);index=0;correct=0;active=true;message.textContent='Choose the answer that comes next.';message.classList.remove('kids-game-complete');show();}
 function show(){const q=order[index];prompt.textContent=q.q;number.textContent=(index+1)+'/5';options.innerHTML='';q.a.forEach((answer,i)=>{const b=document.createElement('button');b.type='button';b.className='kids-choice';b.textContent=answer;b.addEventListener('click',()=>choose(i));options.appendChild(b);});}
 function choose(i){if(!active)return;const q=order[index];[...options.children].forEach(b=>b.disabled=true);if(i===q.correct){correct++;message.textContent='⭐ Correct! Well done.';}else message.textContent='💜 Good try. The next answer is '+q.a[q.correct]+'.';index++;if(index<5){window.setTimeout(show,650);}else{active=false;const score=correct*20;prompt.textContent='Puzzle complete!';number.textContent='5/5';options.innerHTML='';message.textContent='You got '+correct+' out of 5. Your score: '+score+'/100.';saveScore('airport_sequence',score,'sequenceBest');}}
 $('sequenceStart').addEventListener('click',start);
})();

// Word Search — find four fixed words horizontally, left-to-right.
(()=>{
 const grid=$('wordGrid'),foundLabel=$('wordFound'),message=$('wordMessage');
 if(!grid)return;
 const rows=['AIRXQPO','MNTUVCA','SKYHLPQ','BQATONM','WINGRZA','CVHLPQS','PILOTXY'];
 const targets=['AIR','SKY','WING','PILOT'];let target=0,selected=[],found=new Set();
 function render(){grid.innerHTML='';rows.forEach((row,r)=>[...row].forEach((letter,c)=>{const b=document.createElement('button');b.type='button';b.className='kids-word-cell';b.textContent=letter;b.setAttribute('aria-label','Row '+(r+1)+', column '+(c+1)+', '+letter);b.addEventListener('click',()=>pick(r,c,b));grid.appendChild(b);}));foundLabel.textContent=found.size+'/4';}
 function clearSelection(){selected.forEach(x=>x.node.classList.remove('is-selected'));selected=[];}
 function pick(r,c,node){if(found.has(r))return;if(selected.some(x=>x.node===node))return;const word=targets[target];if(selected.length&&r!==selected[0].r){clearSelection();message.textContent='Start at the first letter of the next word.';}
 const expected=word[selected.length];if(letterAt(r,c)!==expected){clearSelection();message.textContent='Not quite. Try the first letter of '+word+'.';return;}
 node.classList.add('is-selected');selected.push({r,c,node});if(selected.length===word.length){selected.forEach(x=>{x.node.classList.remove('is-selected');x.node.classList.add('is-found');x.node.disabled=true;});found.add(r);message.textContent='🌟 You found '+word+'!';target++;selected=[];foundLabel.textContent=found.size+'/4';if(found.size===4){message.textContent='🎉 You found all four words! Excellent work.';message.classList.add('kids-game-complete');saveScore('word_search',100,'wordBest');}else message.textContent+=' Find '+targets[target]+'.';}}
 function letterAt(r,c){return rows[r][c];}
 $('wordReset').addEventListener('click',()=>{target=0;selected=[];found=new Set();message.textContent='Find the four hidden aviation words!';message.classList.remove('kids-game-complete');render();});
 render();
})();
})();
